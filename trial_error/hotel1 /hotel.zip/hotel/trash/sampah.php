<?php
session_start();
include 'header.php';
include 'koneksi.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);


// Check if user is not logged in, redirect to sign_in.php
if (!isset($_SESSION['guest_id'])) {
    header("Location: sign_in.php");
    exit();
}

// Function to get room types and prices from database
function getRoomTypes($conn) {
    $sql = "SELECT room_id, room_type, price FROM rooms WHERE availability = TRUE";
    $result = $conn->query($sql);

    $roomTypes = array();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $roomTypes[$row['room_id']] = array(
                'room_type' => $row['room_type'],
                'price' => $row['price']
            );
        }
    }
    return $roomTypes;
}

// Initialize variables
$name = $email = $checkin = $checkout = $adults = $children = $room_id = $special_request = $price_per_night = $amount = '';

// If form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize inputs
    $guest_id = $_SESSION['guest_id'];
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $checkin = new DateTime($_POST['checkin']); // Assuming you sanitize or validate date appropriately
    $checkout = new DateTime($_POST['checkout']); // Assuming you sanitize or validate date appropriately
    $adults = $_POST['adults']; // Assuming you validate input appropriately
    $children = $_POST['children']; // Assuming you validate input appropriately
    $room_id = $_POST['room']; // Assuming you validate input appropriately
    $special_request = filter_input(INPUT_POST, 'special_request', FILTER_SANITIZE_STRING);

    // Validate price to ensure it's numeric
    $price_per_night = (float)$_POST['price'];
    if (!is_numeric($price_per_night)) {
        die('Failed to parse room price.');
    }

    // Calculate total price
    $interval = $checkin->diff($checkout);
    $nights = $interval->days;
    if ($nights <= 0) {
        die('Check-out date must be later than check-in date.');
    }
    $amount = $nights * $price_per_night;

    // Format check-in and check-out dates as strings
    $checkin_str = $checkin->format('Y-m-d');
    $checkout_str = $checkout->format('Y-m-d');

    // Insert data into bookings table
    $sql = "INSERT INTO bookings (guest_id, room_id, check_in, check_out, adults, children, special_request) 
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }
    $stmt->bind_param("iississ", $guest_id, $room_id, $checkin_str, $checkout_str, $adults, $children, $special_request);

    if ($stmt->execute()) {
        // Get the booking_id that was auto-generated
        $booking_id = $stmt->insert_id;
        $_SESSION['booking_id'] = $booking_id;
        
    
        // Insert data into transactions table
        $payment_method = "Credit Card"; // Replace with actual payment method
        $transaction_status = "Pending"; // Default status
    
        $sql = "INSERT INTO transactions (booking_id, guest_id, amount, payment_method, transaction_status) 
        VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            die("Prepare failed: " . $conn->error);
        }
        $stmt->bind_param("iiiss", $booking_id, $guest_id, $amount, $payment_method, $transaction_status);

        if ($stmt->execute()) {
            // Set session and cookie as needed
            $_SESSION['transaction_id'] = $stmt->insert_id;
            setcookie('booking_id', $_SESSION['transaction_id'], time() + (86400 * 30), "/");

            // Redirect to payment page with transaction_id
            header("Location: payment.php?transaction_id=" . $_SESSION['transaction_id']);
            exit();
        } else {
            echo "Failed to insert transaction: " . $stmt->error;
            exit();
        }

        // Insert data into transactions table
    //     $sql = "INSERT INTO transactions (booking_id, guest_id, amount, payment_method, transaction_status) 
    //             VALUES (?, ?, ?, ?, ?)";
    //     $stmt = $conn->prepare($sql);
    //     if (!$stmt) {
    //         die("Prepare failed: " . $conn->error);
    //     }
    //     $stmt->bind_param("iiiss", $booking_id, $guest_id, $amount, $payment_method, $transaction_status);
    
    //     if ($stmt->execute()) {
    //         // Store booking_id in session for future reference
    //         // $transaction_id = $stmt->insert_id;
    //         // $_SESSION['transaction_id'] = $transaction_id;
    //         // var_dump($_SESSION['transaction_id']); 

    //         // Set cookie with booking_id
    //         // $booking_id = $stmt->insert_id;
    //         // setcookie('booking_id', $booking_id, time() + (86400 * 30), "/"); // expire in 30 days
    //         // header("Location: payment.php?booking_id=$booking_id");
    //         // exit();

    //         $transaction_id = $stmt->insert_id;
    //         $_SESSION['transaction_id'] = $transaction_id;
    //         setcookie('booking_id', $transaction_id, time() + (86400 * 30), "/"); // expire in 30 days
    //         header("Location: payment.php?transaction_id=$transaction_id");
    //         exit(); 

    //         // echo $_SESSION['booking_id'];
    
    //         // Redirect to payment.php after successful booking
    //         // header("Location: payment.php");
    //         // exit();
    //     } else {
    //         // Redirect to error page or handle error message
    //         echo "Failed to insert transaction: " . $stmt->error;
    //         exit();
    //     }
    // } else {
    //     // Redirect to error page or handle error message
    //     echo "Failed to insert booking: " . $stmt->error;
    //     exit();
    }
}    

// var_dump($_SESSION['transaction_id']); 
// echo $_SESSION['transaction_id'];

// Get room types
$roomTypes = getRoomTypes($conn);
?>





<?php
session_start(); // Pastikan session_start() sudah dijalankan jika menggunakan session
include 'koneksi.php'; // File untuk koneksi ke database
include 'header.php';
// Tampilkan semua error untuk debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);
   
// Ambil transaction_id dari GET parameter atau cookie
// if (isset($_GET['transaction_id'])) {
//     $transaction_id = $_GET['transaction_id'];
//     setcookie('transaction_id', $transaction_id, time() + (86400 * 30), "/"); // Atur cookie dengan transaction_id
// } elseif (isset($_COOKIE['transaction_id'])) {
//     $transaction_id = $_COOKIE['transaction_id'];
// } else {
//     echo "Transaction ID not found.";
//     exit();
// }
// echo "Transaction ID: " . $transaction_id . "<br>";
   
// Query database untuk detail transaksi berdasarkan transaction_id
$sql_booking = "SELECT * FROM bookings  WHERE booking_id = ?";
$sql_booking = $conn->prepare($sql_booking);
$sql_booking->bind_param("i", $booking_id);
$sql_booking->execute();
$sql_booking = $sql_booking->get_result();
   
if ($sql_booking === false || $sql_booking->num_rows === 0) {
    echo "Booking data not found.";
    exit();
}
   
$transaction = $result_transaction->fetch_assoc();
$booking_id = $transaction['booking_id']; // Ambil booking_id dari hasil transaksi
   
$query = mysqli_query($conn, "SELECT room_type FROM rooms WHERE room_id ");
while ($data = mysqli_fetch_array($query)) {
    // echo $data['room_type'];
}

// Query database untuk detail booking berdasarkan booking_id
$sql_booking = "SELECT b.*, g.name, g.email, r.room_type
                FROM bookings b
                JOIN guests g ON b.guest_id = g.guest_id
                JOIN rooms r ON b.room_id = r.room_id
                WHERE b.booking_id = ?";

$stmt_booking = $conn->prepare($sql_booking);
$stmt_booking->bind_param("i", $booking_id);
$stmt_booking->execute();
$result_booking = $stmt_booking->get_result();
   
if ($result_booking === false || $result_booking->num_rows === 0) {
    echo "Booking data not found.";
    exit();
}
   
$booking = $result_booking->fetch_assoc();
// print_r($booking); // Uncomment for debugging
   
// Data dari tabel bookings
$guest_name = $booking['name'];
$guest_email = $booking['email'];
$check_in = $booking['check_in'];
$check_out = $booking['check_out'];
$adults = $booking['adults'];
$children = $booking['children'];
$room_type = $booking['room_type'];
$special_request = $booking['special_request'];

// Data dari tabel transactions
$transaction_id = $transaction['transaction_id'];
$amount = $transaction['amount'];
$payment_method = $transaction['payment_method'];
$transaction_status = $transaction['transaction_status'];
?>

<!-- HALO -->
<!-- Page Header Start -->
<div class="container-fluid page-header mb-5 p-0" style="background-image: url(img/carousel-1.jpg);">
    <div class="container-fluid page-header-inner py-5">
        <div class="container text-center pb-5">
            <h1 class="display-3 text-white mb-3 animated slideInDown">Booking Detail</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center text-uppercase">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item"><a href="profile.php">Profile</a></li>
                    <li class="breadcrumb-item text-white active" aria-current="page">Booking Detail</li>
                </ol>
            </nav>
        </div>
    </div>
</div>
<!-- Page Header End -->

<!-- Booking Detail Start -->
<div class="container-xxl py-5">
    <div class="container">
        <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
            <h6 class="section-title text-center text-primary text-uppercase">Booking</h6>
            <h1 class="mb-5">Booking <span class="text-primary text-uppercase">Detail</span></h1>
        </div>
        <div class="row g-5">
            <div class="col-lg-6">
                <div class="wow fadeInUp" data-wow-delay="0.2s">
                    <h3>Booking Information</h3>
                    <ul class="list-group">
                        <!-- <li class="list-group-item">Booking ID: 1</li> -->
                        <li class="list-group-item">Name: <?php echo htmlspecialchars($guest_name); ?></li>
                        <li class="list-group-item">Email: <?php echo htmlspecialchars($guest_email); ?></li>
                        <li class="list-group-item">Check In: <?php echo htmlspecialchars($check_in); ?></li>
                        <li class="list-group-item">Check Out: <?php echo htmlspecialchars($check_out); ?></li>
                        <li class="list-group-item">Adults: <?php echo htmlspecialchars($adults); ?></li>
                        <li class="list-group-item">Children: <?php echo htmlspecialchars($children); ?></li>
                        <li class="list-group-item">Room Type: <?php echo htmlspecialchars($room_type); ?></li>
                        <li class="list-group-item">Special Request: <?php echo htmlspecialchars($special_request); ?></li>
                    </ul>
                </div>
                <div class="wow fadeInUp mt-2" data-wow-delay="0.4s">
                    <h3>Payment Information</h3>
                    <ul class="list-group">
                        <li class="list-group-item">Transaction ID: <?php echo $transaction_id; ?></li>
                        <li class="list-group-item">Amount: $<?php echo $amount; ?></li>
                        <li class="list-group-item">Payment Method: <?php echo $payment_method; ?></li>
                        <li class="list-group-item">Transaction Status: <?php echo $transaction_status; ?></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-6">
            <div class="wow fadeInUp" data-wow-delay="0.4s">
                <h3>Edit Booking</h3>
                <form action="booking_update.php" method="post"> <!-- Assuming update_booking.php handles form submission -->
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="text" class="form-control" id="booking_name" name="booking_name" placeholder="Booking Name" value="<?php echo htmlspecialchars($guest_name); ?>">
                                <label for="booking_name">Booking Name</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="email" class="form-control" id="booking_email" name="booking_email" placeholder="Booking Email" value="<?php echo htmlspecialchars($guest_email); ?>">
                                <label for="booking_email">Booking Email</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-floating date" id="checkin_date" data-target-input="nearest">
                                <input type="text" class="form-control datetimepicker-input" id="checkin" name="checkin" placeholder="Check In" value="<?php echo htmlspecialchars($check_in); ?>" data-target="#checkin_date" data-toggle="datetimepicker" />
                                <label for="checkin">Check In</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-floating date" id="checkout_date" data-target-input="nearest">
                                <input type="text" class="form-control datetimepicker-input" id="checkout" name="checkout" placeholder="Check Out" value="<?php echo htmlspecialchars($check_out); ?>" data-target="#checkout_date" data-toggle="datetimepicker" />
                                <label for="checkout">Check Out</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-floating">
                                <select class="form-select" id="select1" name="adults">
                                    <option value="1" <?php if ($adults == 2) echo 'selected'; ?>>Adults: 2</option>
                                    <option value="2" <?php if ($adults == 1) echo 'selected'; ?>>Adults: 1</option>
                                    <option value="3" <?php if ($adults == 3) echo 'selected'; ?>>Adults: 3</option>
                                </select>
                                <label for="select1">Select Adults</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-floating">
                                <select class="form-select" id="select2" name="children">
                                    <option value="1" <?php if ($children == 1) echo 'selected'; ?>>Children: 1</option>
                                    <option value="2" <?php if ($children == 2) echo 'selected'; ?>>Children: 2</option>
                                    <option value="3" <?php if ($children == 3) echo 'selected'; ?>>Children: 3</option>
                                </select>
                                <label for="select2">Select Children</label>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-floating">
                                <select class="form-select" id="select3" name="room_type">
                                    <option value="1" <?php if ($room_type == 'Deluxe Room') echo 'selected'; ?>>Room Type: Deluxe Room</option>
                                    <option value="2" <?php if ($room_type == 'Suite') echo 'selected'; ?>>Room Type: Suite</option>
                                    <option value="3" <?php if ($room_type == 'Standard Room') echo 'selected'; ?>>Room Type: Standard Room</option>
                                </select>
                                <label for="select3">Select Room Type</label>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-floating">
                                <textarea class="form-control" name="special_request" placeholder="Special Request" id="message" style="height: 100px"><?php echo htmlspecialchars($special_request); ?></textarea>
                                <label for="message">Special Request</label>
                            </div>
                        </div>
                        <input type="hidden" name="booking_id" value="<?php echo $booking_id; ?>">
                        <div class="col-12">
                            <button class="btn btn-primary w-100 py-3" type="submit">Save Changes</button>
                        </div>

                        <!-- GA TAU CANCEL -->

                        <!-- <form action="booking_cancel.php" method="POST">
                            <input type="hidden" name="booking_id" value="<?php echo $booking_id; ?>">
                            <div class="col-12">
                                <button type="submit" class="btn btn-danger w-100 py-3 mt-3" name="cancel_booking">Cancel Booking</button>
                            </div>
                        </form> -->

                        </div>
                    </div>
                </form>
                <div class="wow fadeInUp" data-wow-delay="0.4s">
                <form action="booking_cancel.php" method="POST">
                            <input type="hidden" name="booking_id" value="<?php echo $booking_id; ?>">
                            <div class="col-12">
                                <button type="submit" class="btn btn-danger w-100 py-3 mt-3" name="cancel_booking">Cancel Booking</button>
                            </div>
                        </form></div>
            </div>
        </div>
        </div>
    </div>
</div>
<!-- Booking Detail End -->

<?php include 'footer.php';?>

