<?php
include 'koneksi.php';

// Start session
session_start();

// Redirect if guest_id is not set
if (!isset($_SESSION['guest_id'])) {
    header("Location: sign_in.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize and validate inputs
    $booking_id = $_POST['booking_id'];
    $card_holder_name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $card_number = filter_input(INPUT_POST, 'card_number', FILTER_SANITIZE_STRING);
    $expiry_date = filter_input(INPUT_POST, 'expiry_date', FILTER_SANITIZE_STRING);
    $cvv = filter_input(INPUT_POST, 'cvv', FILTER_SANITIZE_STRING);
    $billing_address = filter_input(INPUT_POST, 'billing_address', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);

    // Insert payment data into payments table
    $sql = "INSERT INTO payments (booking_id, card_holder_name, card_number, expiry_date, cvv, billing_address, email) 
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("issssss", $booking_id, $card_holder_name, $card_number, $expiry_date, $cvv, $billing_address, $email);

    if ($stmt->execute()) {
        // Update transaction status to 'Paid'
        $sql = "UPDATE transactions SET transaction_status = 'Paid' WHERE booking_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $booking_id);
        $stmt->execute();

        // Redirect to success page
        header("Location: payment_success.php");
        exit();
    } else {
        // Redirect to error page
        header("Location: payment_error.php");
        exit();
    }
}
?>
<?php
include 'koneksi.php';

// Start session
session_start();

// Redirect if guest_id is not set
if (!isset($_SESSION['guest_id'])) {
    header("Location: sign_in.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize and validate inputs
    $booking_id = $_POST['booking_id'];
    $card_holder_name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $card_number = filter_input(INPUT_POST, 'card_number', FILTER_SANITIZE_STRING);
    $expiry_date = filter_input(INPUT_POST, 'expiry_date', FILTER_SANITIZE_STRING);
    $cvv = filter_input(INPUT_POST, 'cvv', FILTER_SANITIZE_STRING);
    $billing_address = filter_input(INPUT_POST, 'billing_address', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);

    // Insert payment data into payments table
    $sql = "INSERT INTO payments (booking_id, card_holder_name, card_number, expiry_date, cvv, billing_address, email) 
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("issssss", $booking_id, $card_holder_name, $card_number, $expiry_date, $cvv, $billing_address, $email);

    if ($stmt->execute()) {
        // Update transaction status to 'Paid'
        $sql = "UPDATE transactions SET transaction_status = 'Paid' WHERE booking_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $booking_id);
        $stmt->execute();

        // Redirect to success page
        header("Location: payment_success.php");
        exit();
    } else {
        // Redirect to error page
        header("Location: payment_error.php");
        exit();
    }
}
?>
