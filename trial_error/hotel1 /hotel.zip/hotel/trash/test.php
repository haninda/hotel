<?php 
include 'header.php';
include 'koneksi.php';

// Query untuk mengambil semua booking
$sql = "SELECT b.booking_id, b.guest_id, b.check_in, b.check_out, b.adults, b.children, b.room_id, b.special_request, b.status, b.created_at 
        FROM bookings b 
        LEFT JOIN transactions t ON b.booking_id = t.booking_id 
        ORDER BY b.created_at DESC";
$query = mysqli_query($conn, $sql);

$bookings = [];
while ($row = mysqli_fetch_assoc($query)) {
    $bookings[] = $row;
}

$sql_bookings = mysqli_query($conn, "SELECT booking_id FROM bookings WHERE guest_id = current_guest_id");


?>

<div class="container-xxl py-5">
    <div class="container">
        <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
            <h6 class="section-title text-center text-primary text-uppercase">Bookings</h6>
            <h1 class="mb-5">All <span class="text-primary text-uppercase">Bookings</span></h1>
        </div>
        <div class="row g-5">
            <div class="col-lg-12">
                <div class="wow fadeInUp" data-wow-delay="0.6s">
                    <h3>Booking List</h3>
                    <?php if (count($bookings) > 0): ?>
                        <ul class="list-group">
                            <?php foreach ($bookings as $booking): ?>
                            <li class="list-group-item">
                                Booking #<?php echo htmlspecialchars($booking['booking_id']); ?> 
                                <a href="booking_detail.php?booking_id=<?php echo htmlspecialchars($booking['booking_id']); ?>" class="btn btn-primary btn-sm float-end">View Details</a>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php else: ?>
                        <p>No bookings made yet.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?> 




<?php
session_start(); // Memulai sesi
include 'koneksi.php';
// include 'koneksi.php';
// Misalnya, guest_id disimpan dalam sesi saat pengguna login
$current_guest_id = $_SESSION['guest_id'];

// Membuat koneksi ke database
// $conn = new mysqli("host", "username", "password", "database");

// Memeriksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Query untuk mengambil semua booking
$sql = "SELECT b.booking_id, b.guest_id, b.check_in, b.check_out, b.adults, b.children, b.room_id, b.special_request, b.status, b.created_at 
        FROM bookings b 
        LEFT JOIN transactions t ON b.booking_id = t.booking_id 
        ORDER BY b.created_at DESC";
$query = mysqli_query($conn, $sql);

$bookings = [];
while ($row = mysqli_fetch_assoc($query)) {
    $bookings[] = $row;
}

// Query untuk mengambil booking_id berdasarkan guest_id yang login saat ini
$sql_bookings = mysqli_query($conn, "SELECT booking_id FROM bookings WHERE guest_id = $current_guest_id");

$guest_bookings = [];
while ($row = mysqli_fetch_assoc($sql_bookings)) {
    $guest_bookings[] = $row;
}

// Menampilkan hasil
echo "<h2>All Bookings:</h2>";
foreach ($bookings as $booking) {
    echo "Booking ID: " . $booking['booking_id'] . "<br>";
    // Tampilkan detail lainnya sesuai kebutuhan
}

echo "<h2>Bookings for Current Guest:</h2>";
foreach ($guest_bookings as $booking) {
    echo "Booking ID: " . $booking['booking_id'] . "<br>";
    // Tampilkan detail lainnya sesuai kebutuhan
}

// Menutup koneksi
mysqli_close($conn);
?>
