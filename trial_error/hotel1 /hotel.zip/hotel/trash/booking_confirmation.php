<?php
include 'header.php';
include 'koneksi.php'; // Sesuaikan dengan konfigurasi koneksi Anda

// Pastikan ada parameter trans_id yang diterima
if (isset($_GET['trans_id'])) {
    $trans_id = $_GET['trans_id'];

    // Query untuk mengambil data transaksi berdasarkan trans_id
    $sql = "SELECT * FROM trans WHERE trans_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $trans_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Pastikan ada hasil query
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
?>
        <!-- Page Header Start -->
        <div class="container-fluid page-header mb-5 p-0" style="background-image: url(img/carousel-1.jpg);">
            <div class="container-fluid page-header-inner py-5">
                <div class="container text-center pb-5">
                    <h1 class="display-3 text-white mb-3 animated slideInDown">Booking Confirmation</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center text-uppercase">
                            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="booking.php">Booking</a></li>
                            <li class="breadcrumb-item text-white active" aria-current="page">Booking Confirmation</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <!-- Page Header End -->

        <!-- Booking Confirmation Details Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                    <h6 class="section-title text-center text-primary text-uppercase">Booking Confirmation</h6>
                    <h1 class="mb-5">Your <span class="text-primary text-uppercase">Booking Details</span></h1>
                </div>
                <div class="row g-5">
                    <div class="col-lg-6">
                        <div class="wow fadeInUp" data-wow-delay="0.2s">
                            <h3>Booking Details</h3>
                            <ul class="list-group">
                                <li class="list-group-item">Name: <?php echo htmlspecialchars($row['guest_name']); ?></li>
                                <li class="list-group-item">Email: <?php echo htmlspecialchars($row['guest_email']); ?></li>
                                <li class="list-group-item">Check In: <?php echo htmlspecialchars($row['check_in']); ?></li>
                                <li class="list-group-item">Check Out: <?php echo htmlspecialchars($row['check_out']); ?></li>
                                <li class="list-group-item">Adults: <?php echo htmlspecialchars($row['adults']); ?></li>
                                <li class="list-group-item">Children: <?php echo htmlspecialchars($row['children']); ?></li>
                                <li class="list-group-item">Room Type: <?php echo htmlspecialchars($row['room_type']); ?></li>
                                <li class="list-group-item">Special Request: <?php echo htmlspecialchars($row['special_request']); ?></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="wow fadeInUp" data-wow-delay="0.4s">
                            <h3>Payment Summary</h3>
                            <ul class="list-group">
                                <li class="list-group-item">Room Price: <?php echo htmlspecialchars($row['room_price']); ?> per night</li>
                                <li class="list-group-item">Number of Nights: <?php echo htmlspecialchars($row['num_of_nights']); ?></li>
                                <li class="list-group-item">Subtotal: <?php echo htmlspecialchars($row['subtotal']); ?></li>
                                <li class="list-group-item">Tax (<?php echo htmlspecialchars($row['tax_rate']); ?>%): <?php echo htmlspecialchars($row['tax_amount']); ?></li>
                                <li class="list-group-item"><strong>Total: <?php echo htmlspecialchars($row['total_amount']); ?></strong></li>
                            </ul>
                            <form action="payment.php" method="GET">
                                <input type="hidden" name="trans_id" value="<?php echo $trans_id; ?>">
                                <button class="btn btn-primary w-100 py-3 mt-3" type="submit">Proceed to Payment</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Booking Confirmation Details End -->

<?php
    } else {
        // Jika transaksi tidak ditemukan
        echo "<div class='container'><p class='alert alert-danger'>Transaction not found.</p></div>";
    }
} else {
    // Jika parameter trans_id tidak diterima
    echo "<div class='container'><p class='alert alert-danger'>Invalid request.</p></div>";
}

include 'footer.php';
?>
