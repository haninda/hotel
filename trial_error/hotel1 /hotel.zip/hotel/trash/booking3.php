<?php
session_start();
include 'header.php';
include 'koneksi.php'; // File untuk koneksi ke database, sesuaikan dengan konfigurasi Anda

if (!isset($_SESSION['guest_id'])) {
    header("Location: sign_in.php");
    exit();
}

// Jika form telah disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil data dari form
    $name = $_POST['name'];
    $email = $_POST['email'];
    $check_in = $_POST['checkin'];
    $check_out = $_POST['checkout'];
    $adults = $_POST['select1'];
    $children = $_POST['select2'];
    $room_id = $_POST['select3'];
    $special_request = $_POST['message'];

    // Validasi data (sebaiknya tambahkan validasi sesuai kebutuhan)

    // Hitung total hari
    $start_date = strtotime($check_in);
    $end_date = strtotime($check_out);
    $total_days = ceil(abs($end_date - $start_date) / 86400); // 86400 detik per hari

    // Ambil harga kamar dari database
    $sql_price = "SELECT price FROM rooms WHERE room_id = ?";
    $stmt_price = $conn->prepare($sql_price);
    $stmt_price->bind_param("i", $room_id);
    $stmt_price->execute();
    $result_price = $stmt_price->get_result();

    if ($result_price->num_rows > 0) {
        $row_price = $result_price->fetch_assoc();
        $price_per_night = $row_price['price'];

        // Hitung amount berdasarkan harga kamar dan total hari
        $amount = $price_per_night * $total_days;

        // Lakukan operasi SQL untuk menyimpan data ke dalam tabel `trans`
        $sql = "INSERT INTO trans (guests_id, room_id, check_in, check_out, adults, children, special_request, status, amount, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?, NOW())";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iissssid", $guests_id, $room_id, $check_in, $check_out, $adults, $children, $special_request, $amount);

        // Dapatkan guests_id berdasarkan email dari tabel guests (atau sesuai dengan struktur data Anda)
        $guests_id = get_guest_id($conn, $email);

        // Eksekusi statement SQL
        if ($stmt->execute()) {
            // Redirect ke halaman konfirmasi booking dengan trans_id
            $trans_id = $stmt->insert_id; // Ambil ID transaksi yang baru saja dimasukkan

            // Redirect ke halaman booking_confirmation.php dengan parameter trans_id
            header("Location: booking_confirmation.php?trans_id=" . $trans_id);
            exit();
        } else {
            // Redirect ke halaman error atau tampilkan pesan error
            header("Location: booking_error.php");
            exit();
        }
    } else {
        // Jika harga kamar tidak ditemukan, mungkin Anda ingin menangani kasus ini
        header("Location: booking_error.php");
        exit();
    }
}

// Fungsi untuk mendapatkan guests_id berdasarkan email (sesuaikan dengan struktur data Anda)
function get_guest_id($conn, $email) {
    $sql = "SELECT guests_id FROM guests WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['guests_id'];
    } else {
        // Jika guest tidak ditemukan, Anda mungkin ingin menangani kasus ini
        return null;
    }
}
?>
<!-- Page Header Start -->
<div class="container-fluid page-header mb-5 p-0" style="background-image: url(img/carousel-1.jpg);">
    <div class="container-fluid page-header-inner py-5">
        <div class="container text-center pb-5">
            <h1 class="display-3 text-white mb-3 animated slideInDown">Booking</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center text-uppercase">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item text-white active" aria-current="page">Booking</li>
                </ol>
            </nav>
        </div>
    </div>
</div>
<!-- Page Header End -->

<!-- Booking Start -->
<div class="container-xxl py-5">
    <div class="container">
        <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
            <h6 class="section-title text-center text-primary text-uppercase">Room Booking</h6>
            <h1 class="mb-5">Book A <span class="text-primary text-uppercase">Luxury Room</span></h1>
        </div>
        <div class="row g-5">
            <div class="col-lg-6">
                <div class="row g-3">
                    <div class="col-6 text-end">
                        <img class="img-fluid rounded w-75 wow zoomIn" data-wow-delay="0.1s" src="img/about-1.jpg" style="margin-top: 25%;">
                    </div>
                    <div class="col-6 text-start">
                        <img class="img-fluid rounded w-100 wow zoomIn" data-wow-delay="0.3s" src="img/about-2.jpg">
                    </div>
                    <div class="col-6 text-end">
                        <img class="img-fluid rounded w-50 wow zoomIn" data-wow-delay="0.5s" src="img/about-3.jpg">
                    </div>
                    <div class="col-6 text-start">
                        <img class="img-fluid rounded w-75 wow zoomIn" data-wow-delay="0.7s" src="img/about-4.jpg">
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="wow fadeInUp" data-wow-delay="0.2s">
                    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="text" class="form-control" id="name" name="name" placeholder="Your Name" required>
                                    <label for="name">Your Name</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="email" class="form-control" id="email" name="email" placeholder="Your Email" required>
                                    <label for="email">Your Email</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating date" id="date3" data-target-input="nearest">
                                    <input type="text" class="form-control datetimepicker-input" id="checkin" name="checkin" placeholder="Check In" data-target="#date3" data-toggle="datetimepicker" required />
                                    <label for="checkin">Check In</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating date" id="date4" data-target-input="nearest">
                                    <input type="text" class="form-control datetimepicker-input" id="checkout" name="checkout" placeholder="Check Out" data-target="#date4" data-toggle="datetimepicker" required />
                                    <label for="checkout">Check Out</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <select class="form-select" id="select1" name="select1" required>
                                        <option value="1">Adult 1</option>
                                        <option value="2">Adult 2</option>
                                        <option value="3">Adult 3</option>
                                    </select>
                                    <label for="select1">Select Adult</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <select class="form-select" id="select2" name="select2" required>
                                        <option value="1">Child 1</option>
                                        <option value="2">Child 2</option>
                                        <option value="3">Child 3</option>
                                    </select>
                                    <label for="select2">Select Child</label>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-floating">
                                    <select class="form-select" id="select3" name="select3" required>
                                        <option value="1">Room 1</option>
                                        <option value="2">Room 2</option>
                                        <option value="3">Room 3</option>
                                    </select>
                                    <label for="select3">Select A Room</label>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-floating">
                                    <textarea class="form-control" placeholder="Special Request" id="message" name="message" style="height: 100px"></textarea>
                                    <label for="message">Special Request</label>
                                </div>
                            </div>
                            <div class="col-12">
                                <button class="btn btn-primary w-100 py-3" type="submit">Book Now</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Booking End -->

<?php include 'footer.php'; ?>
