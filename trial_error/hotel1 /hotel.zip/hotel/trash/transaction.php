<?php
session_start();
include 'koneksi.php';
include 'booking.php';

    // if (!isset($_SESSION['guest_id'])) {
    //     header("Location: sign_in.php");
    //     exit();
    // }

    if ($stmt->execute()) {
        // Get the booking_id that was auto-generated
        $booking_id = $stmt->insert_id;

        // Insert data into transactions table
        // $payment_method = "Credit Card"; // Replace with actual payment method
        // $transaction_status = "Pending"; // Default status

        // Insert data into transactions table
        $sql = "INSERT INTO transactions (booking_id, guest_id, amount, payment_method, transaction_status) 
        VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iiiss", $booking_id, $guest_id, $amount, $payment_method, $transaction_status);

        if ($stmt->execute()) {
        // Redirect to payment.php after successful booking
        // header("Location: payment.php");
        echo "berhasil";
        exit();
        } else {
        // Redirect to error page or handle error message
        // header("Location: booking_error.php");
        echo "gagal 2";
        exit();
        }

    } else {
        // Redirect to error page or handle error message
        // header("Location: booking_error.php");
        echo('gagal 3');
        exit();
    }
?>