<?php
session_start(); // Pastikan session_start() sudah dijalankan jika menggunakan session
include 'koneksi.php'; // File untuk koneksi ke database
include 'header.php';
// Tampilkan semua error untuk debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);
   
// Ambil transaction_id dari GET parameter atau cookie
// if (isset($_GET['transaction_id'])) {
//     $transaction_id = $_GET['transaction_id'];
//     setcookie('transaction_id', $transaction_id, time() + (86400 * 30), "/"); // Atur cookie dengan transaction_id
// } elseif (isset($_COOKIE['transaction_id'])) {
//     $transaction_id = $_COOKIE['transaction_id'];
// } else {
//     echo "Transaction ID not found.";
//     exit();
// }
// echo "Transaction ID: " . $transaction_id . "<br>";
   
// Query database untuk detail transaksi berdasarkan transaction_id
$sql_booking = "SELECT * FROM bookings  WHERE booking_id = ?";
$sql_booking = $conn->prepare($sql_booking);
$sql_booking->bind_param("i", $booking_id);
$sql_booking->execute();
$sql_booking = $sql_booking->get_result();
   
if ($sql_booking === false || $sql_booking->num_rows === 0) {
    echo "Booking data not found.";
    exit();
}
   
$transaction = $result_transaction->fetch_assoc();
$booking_id = $transaction['booking_id']; // Ambil booking_id dari hasil transaksi
   
$query = mysqli_query($conn, "SELECT room_type FROM rooms WHERE room_id ");
while ($data = mysqli_fetch_array($query)) {
    // echo $data['room_type'];
}

// Query database untuk detail booking berdasarkan booking_id
$sql_booking = "SELECT b.*, g.name, g.email, r.room_type
                FROM bookings b
                JOIN guests g ON b.guest_id = g.guest_id
                JOIN rooms r ON b.room_id = r.room_id
                WHERE b.booking_id = ?";

$stmt_booking = $conn->prepare($sql_booking);
$stmt_booking->bind_param("i", $booking_id);
$stmt_booking->execute();
$result_booking = $stmt_booking->get_result();
   
if ($result_booking === false || $result_booking->num_rows === 0) {
    echo "Booking data not found.";
    exit();
}
   
$booking = $result_booking->fetch_assoc();
// print_r($booking); // Uncomment for debugging
   
// Data dari tabel bookings
$guest_name = $booking['name'];
$guest_email = $booking['email'];
$check_in = $booking['check_in'];
$check_out = $booking['check_out'];
$adults = $booking['adults'];
$children = $booking['children'];
$room_type = $booking['room_type'];
$special_request = $booking['special_request'];

// Data dari tabel transactions
$transaction_id = $transaction['transaction_id'];
$amount = $transaction['amount'];
$payment_method = $transaction['payment_method'];
$transaction_status = $transaction['transaction_status'];
?>

<!-- HALO -->
<!-- Page Header Start -->
<div class="container-fluid page-header mb-5 p-0" style="background-image: url(img/carousel-1.jpg);">
    <div class="container-fluid page-header-inner py-5">
        <div class="container text-center pb-5">
            <h1 class="display-3 text-white mb-3 animated slideInDown">Booking Detail</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center text-uppercase">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item"><a href="profile.php">Profile</a></li>
                    <li class="breadcrumb-item text-white active" aria-current="page">Booking Detail</li>
                </ol>
            </nav>
        </div>
    </div>
</div>
<!-- Page Header End -->

<!-- Booking Detail Start -->
<div class="container-xxl py-5">
    <div class="container">
        <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
            <h6 class="section-title text-center text-primary text-uppercase">Booking</h6>
            <h1 class="mb-5">Booking <span class="text-primary text-uppercase">Detail</span></h1>
        </div>
        <div class="row g-5">
            <div class="col-lg-6">
                <div class="wow fadeInUp" data-wow-delay="0.2s">
                    <h3>Booking Information</h3>
                    <ul class="list-group">
                        <!-- <li class="list-group-item">Booking ID: 1</li> -->
                        <li class="list-group-item">Name: <?php echo htmlspecialchars($guest_name); ?></li>
                        <li class="list-group-item">Email: <?php echo htmlspecialchars($guest_email); ?></li>
                        <li class="list-group-item">Check In: <?php echo htmlspecialchars($check_in); ?></li>
                        <li class="list-group-item">Check Out: <?php echo htmlspecialchars($check_out); ?></li>
                        <li class="list-group-item">Adults: <?php echo htmlspecialchars($adults); ?></li>
                        <li class="list-group-item">Children: <?php echo htmlspecialchars($children); ?></li>
                        <li class="list-group-item">Room Type: <?php echo htmlspecialchars($room_type); ?></li>
                        <li class="list-group-item">Special Request: <?php echo htmlspecialchars($special_request); ?></li>
                    </ul>
                </div>
                <div class="wow fadeInUp mt-2" data-wow-delay="0.4s">
                    <h3>Payment Information</h3>
                    <ul class="list-group">
                        <li class="list-group-item">Transaction ID: <?php echo $transaction_id; ?></li>
                        <li class="list-group-item">Amount: $<?php echo $amount; ?></li>
                        <li class="list-group-item">Payment Method: <?php echo $payment_method; ?></li>
                        <li class="list-group-item">Transaction Status: <?php echo $transaction_status; ?></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-6">
            <div class="wow fadeInUp" data-wow-delay="0.4s">
                <h3>Edit Booking</h3>
                <form action="booking_update.php" method="post"> <!-- Assuming update_booking.php handles form submission -->
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="text" class="form-control" id="booking_name" name="booking_name" placeholder="Booking Name" value="<?php echo htmlspecialchars($guest_name); ?>">
                                <label for="booking_name">Booking Name</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="email" class="form-control" id="booking_email" name="booking_email" placeholder="Booking Email" value="<?php echo htmlspecialchars($guest_email); ?>">
                                <label for="booking_email">Booking Email</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-floating date" id="checkin_date" data-target-input="nearest">
                                <input type="text" class="form-control datetimepicker-input" id="checkin" name="checkin" placeholder="Check In" value="<?php echo htmlspecialchars($check_in); ?>" data-target="#checkin_date" data-toggle="datetimepicker" />
                                <label for="checkin">Check In</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-floating date" id="checkout_date" data-target-input="nearest">
                                <input type="text" class="form-control datetimepicker-input" id="checkout" name="checkout" placeholder="Check Out" value="<?php echo htmlspecialchars($check_out); ?>" data-target="#checkout_date" data-toggle="datetimepicker" />
                                <label for="checkout">Check Out</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-floating">
                                <select class="form-select" id="select1" name="adults">
                                    <option value="1" <?php if ($adults == 2) echo 'selected'; ?>>Adults: 2</option>
                                    <option value="2" <?php if ($adults == 1) echo 'selected'; ?>>Adults: 1</option>
                                    <option value="3" <?php if ($adults == 3) echo 'selected'; ?>>Adults: 3</option>
                                </select>
                                <label for="select1">Select Adults</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-floating">
                                <select class="form-select" id="select2" name="children">
                                    <option value="1" <?php if ($children == 1) echo 'selected'; ?>>Children: 1</option>
                                    <option value="2" <?php if ($children == 2) echo 'selected'; ?>>Children: 2</option>
                                    <option value="3" <?php if ($children == 3) echo 'selected'; ?>>Children: 3</option>
                                </select>
                                <label for="select2">Select Children</label>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-floating">
                                <select class="form-select" id="select3" name="room_type">
                                    <option value="1" <?php if ($room_type == 'Deluxe Room') echo 'selected'; ?>>Room Type: Deluxe Room</option>
                                    <option value="2" <?php if ($room_type == 'Suite') echo 'selected'; ?>>Room Type: Suite</option>
                                    <option value="3" <?php if ($room_type == 'Standard Room') echo 'selected'; ?>>Room Type: Standard Room</option>
                                </select>
                                <label for="select3">Select Room Type</label>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-floating">
                                <textarea class="form-control" name="special_request" placeholder="Special Request" id="message" style="height: 100px"><?php echo htmlspecialchars($special_request); ?></textarea>
                                <label for="message">Special Request</label>
                            </div>
                        </div>
                        <input type="hidden" name="booking_id" value="<?php echo $booking_id; ?>">
                        <div class="col-12">
                            <button class="btn btn-primary w-100 py-3" type="submit">Save Changes</button>
                        </div>

                        <!-- GA TAU CANCEL -->

                        <!-- <form action="booking_cancel.php" method="POST">
                            <input type="hidden" name="booking_id" value="<?php echo $booking_id; ?>">
                            <div class="col-12">
                                <button type="submit" class="btn btn-danger w-100 py-3 mt-3" name="cancel_booking">Cancel Booking</button>
                            </div>
                        </form> -->

                        </div>
                    </div>
                </form>
                <div class="wow fadeInUp" data-wow-delay="0.4s">
                <form action="booking_cancel.php" method="POST">
                            <input type="hidden" name="booking_id" value="<?php echo $booking_id; ?>">
                            <div class="col-12">
                                <button type="submit" class="btn btn-danger w-100 py-3 mt-3" name="cancel_booking">Cancel Booking</button>
                            </div>
                        </form></div>
            </div>
        </div>
        </div>
    </div>
</div>
<!-- Booking Detail End -->

<?php include 'footer.php';?>
