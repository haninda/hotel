-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 24, 2024 at 04:25 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotel3`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `booking_id` int(11) NOT NULL,
  `guest_id` int(11) DEFAULT NULL,
  `room_id` int(11) DEFAULT NULL,
  `check_in` date NOT NULL,
  `check_out` date NOT NULL,
  `adults` int(11) NOT NULL,
  `children` int(11) NOT NULL,
  `special_request` text DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Booked',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`booking_id`, `guest_id`, `room_id`, `check_in`, `check_out`, `adults`, `children`, `special_request`, `status`, `created_at`) VALUES
(59, 6, 2, '2024-06-23', '2024-06-25', 2, 0, 'han', 'Booked', '2024-06-23 12:51:49'),
(77, 5, 2, '2024-06-27', '2024-06-28', 2, 0, 'a', 'Booked', '2024-06-23 16:14:42'),
(78, 5, 2, '2024-07-01', '2024-07-03', 3, 0, 'l', 'Booked', '2024-06-23 16:23:08'),
(79, 6, 2, '2024-06-24', '2024-06-30', 1, 0, 'one', 'Booked', '2024-06-24 02:18:58'),
(80, 6, 2, '2024-06-24', '2024-06-25', 2, 0, 'j', 'Booked', '2024-06-24 02:23:42');

-- --------------------------------------------------------

--
-- Table structure for table `guests`
--

CREATE TABLE `guests` (
  `guest_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` int(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `guests`
--

INSERT INTO `guests` (`guest_id`, `name`, `email`, `phone`, `password`, `created_at`) VALUES
(5, 'faisa', 'faisa@gmail.com', 12345676, '111', '2024-06-22 08:41:06'),
(6, 'wonuu', 'wonu@gmail.com', 1232445, '000', '2024-06-22 09:32:45');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL,
  `transaction_id` int(11) DEFAULT NULL,
  `guest_id` int(11) DEFAULT NULL,
  `payment_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `amount` decimal(10,2) NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `payment_status` varchar(20) DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `transaction_id`, `guest_id`, `payment_date`, `amount`, `payment_method`, `payment_status`, `created_at`) VALUES
(1, 36, 6, '2024-06-23 12:54:18', '14000000.00', 'Credit Card', 'Success', '2024-06-23 12:54:18'),
(6, 53, 5, '2024-06-23 16:15:00', '7000000.00', 'Credit Card', 'Success', '2024-06-23 16:15:00'),
(7, 54, 5, '2024-06-23 16:23:19', '14000000.00', 'Credit Card', 'Success', '2024-06-23 16:23:19'),
(8, 55, 6, '2024-06-24 02:19:15', '42000000.00', 'Credit Card', 'Success', '2024-06-24 02:19:15'),
(9, 56, 6, '2024-06-24 02:23:49', '7000000.00', 'Credit Card', 'Success', '2024-06-24 02:23:49');

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `room_id` int(11) NOT NULL,
  `room_type` varchar(50) NOT NULL,
  `price` double NOT NULL,
  `availability` tinyint(1) DEFAULT 1,
  `description` text DEFAULT NULL,
  `bed` int(2) DEFAULT NULL,
  `bath` int(2) DEFAULT NULL,
  `wifi` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`room_id`, `room_type`, `price`, `availability`, `description`, `bed`, `bath`, `wifi`, `created_at`) VALUES
(1, 'Super Deluxe', 10000000, 1, 'Super Deluxe Room menawarkan pengalaman menginap yang luar biasa dengan kombinasi kemewahan dan kenyamanan. Kamar ini lebih besar dari kamar deluxe biasa dan dilengkapi dengan fasilitas modern serta pemandangan yang indah.', 2, 2, 1, '2024-06-22 08:05:16'),
(2, 'Executive Suite', 7000000, 1, 'Executive Suite menawarkan kemewahan dan ruang yang lebih luas, ideal untuk tamu yang membutuhkan fasilitas tambahan dan privasi. Kamar ini memiliki ruang tamu terpisah. Desain interiornya modern dan elegan, memberikan kesan eksklusif dan prestisius.', 2, 2, 1, '2024-06-22 08:05:55'),
(3, 'Junior Suite', 5000000, 1, 'Junior Suite dirancang untuk memberikan kenyamanan dan kemewahan. Kamar ini biasanya dilengkapi dengan area tempat duduk terpisah. Interiornya elegan dengan perabotan modern dan dekorasi yang menawan, menciptakan suasana yang hangat dan ramah.', 2, 1, 1, '2024-06-22 08:06:30');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `transaction_id` int(11) NOT NULL,
  `booking_id` int(11) DEFAULT NULL,
  `guest_id` int(11) DEFAULT NULL,
  `transaction_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `amount` double NOT NULL,
  `payment_method` varchar(20) NOT NULL DEFAULT 'Credit Card',
  `transaction_status` varchar(20) DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`transaction_id`, `booking_id`, `guest_id`, `transaction_date`, `amount`, `payment_method`, `transaction_status`, `created_at`) VALUES
(36, 59, 6, '2024-06-23 12:51:49', 14000000, 'Credit Card', 'Completed', '2024-06-23 12:51:49'),
(53, 77, 5, '2024-06-23 16:14:42', 7000000, 'Credit Card', 'Completed', '2024-06-23 16:14:42'),
(54, 78, 5, '2024-06-23 16:23:08', 14000000, 'Credit Card', 'Completed', '2024-06-23 16:23:08'),
(55, 79, 6, '2024-06-24 02:18:58', 42000000, 'Credit Card', 'Completed', '2024-06-24 02:18:58'),
(56, 80, 6, '2024-06-24 02:23:42', 7000000, 'Credit Card', 'Completed', '2024-06-24 02:23:42');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`booking_id`),
  ADD KEY `room_id` (`room_id`);

--
-- Indexes for table `guests`
--
ALTER TABLE `guests`
  ADD PRIMARY KEY (`guest_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `transaction_id` (`transaction_id`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`room_id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`transaction_id`),
  ADD UNIQUE KEY `booking_id` (`booking_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT for table `guests`
--
ALTER TABLE `guests`
  MODIFY `guest_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `room_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`guest_id`) REFERENCES `guests` (`guest_id`),
  ADD CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`room_id`);

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`transaction_id`);

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `fk_booking_id` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`booking_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`booking_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
